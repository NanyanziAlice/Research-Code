%%
%%%Mellin transform Laplacian Matrix

function LM = computeMellin(G,s)
    d = distances(G);
    [r,c] = size(d);
    for i = 1:(r-1)
        for j = (i+1):c
           if d(i,j)~= 1
               val = 1.0/d(i,j)^s;
               d(i,j)= val;
               d(j,i)= val;
           end
        end
    end
    LM = diag(sum(d))-d;
end


