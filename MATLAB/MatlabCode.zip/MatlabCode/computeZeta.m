%img = imread('./cups/cup.png');
%Seq = loadImages('cups/', '*.png');
function zVal = computeZeta(s,direc,imagetype, thres, rup, rdown)
    zVal= [];
    cc=1;
    for i = 0 : 5: 80
        img = imread(strcat(direc,num2str(i),imagetype));
        %thr=adjust_thresh(img);
        im=rgb2gray(img);
        [cim,r,c]= harris4(im,1,thres,2);
        %discard corner points at the extremes
        cod = [c(:), r(:)];
        cod = cod(rup:end,:);
        cod = cod(1:end-rdown,:);
        % Delaunay triangulation
        tri = delaunay(cod(:,1),cod(:,2));
        %create graph from delanauy, compute adjacency and Laplacian
        %matrices
        g = digraph(tri, tri(:, [2 3 1]));
        A = adjacency(g);
        A = sparse(A | A');
        L = diag(sum(A))-A;
        
        %column vector of eigenvalues of Laplacian
        eg = transpose(eig(full(L)));
        zSum= 0;
        % compute zeta function for a given exponent s
        if s==1    
            for k = 2 : length(eg)
                zSum = zSum+ 1.0/(eg(:,k));
            end
        end
        if s>1
           for k = 2 : length(eg)
                zSum = zSum+ 1.0/(eg(:,k)^s);
           end
        end
        zVal(cc,:) = zSum;
        cc = cc+1;
    end
end